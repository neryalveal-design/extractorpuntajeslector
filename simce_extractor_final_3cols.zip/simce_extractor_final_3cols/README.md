# SIMCE / PAES App - Análisis y Gráficos

Incluye exportación a PDF y visualización múltiple de gráficos.
